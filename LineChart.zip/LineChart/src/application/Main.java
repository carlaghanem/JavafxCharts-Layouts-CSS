package application;

import javafx.scene.chart.*;

import java.util.Locale.Category;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;
 
 
public class Main extends Application {
 
    @Override public void start(Stage stage) {
        stage.setTitle("Line Chart Sample");
        
        //Step 1: defining the axes
              CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Month");
        
        //Step 2: creating the chart
        final LineChart lineChart = new LineChart(xAxis,yAxis);    
        lineChart.setTitle("Monthly Reported Corona Cases - City X - 2020");
        
        //Step 3: Passing Data to XY Charts
        
        //defining a series
        XYChart.Series series = new XYChart.Series();
        series.setName("COVID-19 Cases");
        
        //populating the series with data
        series.getData().add(new XYChart.Data("January", 4));
        series.getData().add(new XYChart.Data("February", 14));
        series.getData().add(new XYChart.Data("March", 40));
        series.getData().add(new XYChart.Data("April", 60));
        series.getData().add(new XYChart.Data("May", 23));
        series.getData().add(new XYChart.Data("June", 56));
        series.getData().add(new XYChart.Data("July", 66));
        series.getData().add(new XYChart.Data("August", 79));
        series.getData().add(new XYChart.Data("September", 85));
        
        
        Scene scene  = new Scene(lineChart,800,600);
        scene.getStylesheets().add("application.css");
        lineChart.getData().add(series);
       
        stage.setScene(scene);
        stage.show();
    }
 
    public static void main(String[] args) {
        launch(args);
    }
}